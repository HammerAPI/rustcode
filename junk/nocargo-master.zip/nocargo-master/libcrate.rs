pub fn double(x: f64) -> f64 {
    x + x
}
