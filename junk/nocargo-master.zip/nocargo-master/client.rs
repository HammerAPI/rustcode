fn main() {
    println!("{}", libcrate::double(2.0));
}
